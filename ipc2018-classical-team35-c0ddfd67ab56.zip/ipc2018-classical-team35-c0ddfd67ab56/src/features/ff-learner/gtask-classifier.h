/*
** Goal Task Classifier for ROLLER
** Tomas de la Rosa
** Started on Sept 28, 2011
*/

#ifndef   	GTASK_H_
# define   	GTASK_H_


#include "matcher.h"


LTnode *GT_tree_head;


void classify_goaltask (void);

#endif 	   
